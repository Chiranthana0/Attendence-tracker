<?php include("header.php"); ?>




<div class="container-fluid jumbo_user mx-auto">

  <h2 class="text-center">STUDENT SPACE</h2>

   <br>
   <h1 class="text-center" >DASHBOARD</h1>
   <br>

 <div class="rows">
 
  <div class="col-sm-6 color_white col-sm-6-mod">
    <h3 class="text-center">Check EID </h3>
	<br>
    <a class="a_color"  href="vieweid.php"><button type="button" class="btn btn-primary btn-lg4">Find EID</button></a>
  
  </div>
  <div class="col-sm-6 color_white col-sm-6-mod">
   <h3 class="text-center">View Attendance</h3>
	<br>
   <a class="a_color" href="viewattendanceuser.php"><button type="button" class="btn btn-primary btn-lg4">Attendance</button></a>
    
  </div>
  
 </div>
 
 </div>






