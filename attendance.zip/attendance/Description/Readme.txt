(Make Sure Your WAMP OR XAMPP server is started and working properly.)




1.-Go to (http://127.0.0.1/phpmyadmin/).
 1.1-enter user as (root);
 1.2- left passward field blank.No password is required.

2.-Click on new which is at top left. i.e- (http://127.0.0.1/phpmyadmin/server_databases.php?server=1).
 2.1- click on (Import) which is 6th option on top navbar.
 2.2- click on browse and select (attendance.sql) click on (open).
 2.3- scroll to bottom then click on (Go).
 2.4- BOOOOOOOMMMM--!!!!!! your database created.

3.Now open (http://127.0.0.1/attendancemanagementsystem/index.php) in new tab on any browser.;
 3.1- Click on (admin Space);
 3.2- Now login with username as (admin) and password as (admin);
 3.3-BOOOOOMMMM--!!!!! now you can add new admin and delete default i.e.(admin);

4.Now you are all set to use it's feature .


Note:-

   => default username is (admin) and password is (admin);
   => make sure your WAMP OR XAMPP server is open and working properly.
  
                                                           

!!!!!!.........Thank me later......!!!!!!!!!

Note:-
           =>  For any modification you can contact me on "cse.deepakyadav@gmail.com". <=

