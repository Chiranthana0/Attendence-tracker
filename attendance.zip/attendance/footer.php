<footer>
  <div class="container">
      <div class="footer-box">
	  <?php 
	        date_default_timezone_set('Asia/Kolkata');
	           $date = date("Y-m-d");
               $newDate = date("d-m-Y", strtotime($date));
      ?>			   
               
        <p>CREATED BY :   SRINIDHI N JOSHI </p>
                            <p> ANVITHA BHASKAR</p>
                            <p>CHIRANTHANA B U </p>
		</div>
  </div>
</footer>
</body>
</html>