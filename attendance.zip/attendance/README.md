# Employee-or-Student-Attendance-Management-System-in-PHP-and-MYSQL
A complete and Advanced attendance management system build in PHP and MYSQL with a massive User Interface.This Project is very easy for both Admin and Users.This project is one of the best example of Content Management System (CMS) Using PHP and MYSQL.
